var firebaseConfig = {
  apiKey: "AIzaSyBlJce00ZsUzu7aRsEEZqNR4roahzYmP8U",
    authDomain: "fir-javas-d58af.firebaseapp.com",
    databaseURL: "https://fir-javas-d58af-default-rtdb.firebaseio.com",
    projectId: "fir-javas-d58af",
    storageBucket: "fir-javas-d58af.appspot.com",
    messagingSenderId: "26573631404",
    appId: "1:26573631404:web:b7c4095d232b933f6b5409"
  };


firebase.initializeApp(firebaseConfig);