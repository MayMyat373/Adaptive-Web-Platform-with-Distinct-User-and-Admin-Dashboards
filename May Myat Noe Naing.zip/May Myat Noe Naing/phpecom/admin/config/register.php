<?php include('navbar.php');?>
<div class="container">
<div class="'row justify-content-center">
<div class="col-md-8">
    <div class="card">
    <div class="box">
        <div class="card-header">
        <div class="box">
        <h4>registration form</h4>
        </div>
        <div class="card-body">
        <form>
            
<div class="box">
<div class="form-group">
   




<div class="form-group">
<div class="mb-3">
<label for="exampleIinput1">Name</label>
<input type="name" name="ame"class="form-control" placeholder="--Name--">

</div>

<div class="form-group">
<div class="mb-3">
<label for="exampleIinput1">email</label>
<input type="email" name="first name" class="form-control" placeholder="--email--">

</div>





<div class="form-group">
<div class="mb-3">
<label for="exampleIinput1">phone</label>
<input type="" name="phone"class="form-control" placeholder="--Password--">

</div>


<div class="form-group">
<div class="mb-3">
<label for="exampleIinput1">Password</label>
<input type="Password" name="pasword"class="form-control" placeholder="--Password--">
</div>


<div class="form-group">
<div class="mb-3">
<label for="exampleIinput1">Re-Enter Password</label>
<input type="" name="cPassword"class="form-control" placeholder="--Re-Enter Password--">
</div>
<div class="mb-3">


</div>

<div class="btn">
  <a class="btn" href="" type="button">submit</a></div>
</div></form>
        </div></div>
    </div>
    </div>
    </div>
</div>
</div>
</div>

</div>
</div>
</div>
</div>

<style>
    .mb-3{
        padding: 15px;
    }
    .container{
padding-top: 10px;
margin: 10px;

    }
    input[type="last name"]::placeholder {
  text-indent: 25px;
}
input[type="last name"]::placeholder {
  padding-top: 10%;
}
    ::-webkit-input-placeholder { 
  font-size: 12px;
  line-height: 1.5;
  text-align: center;


}
    .box{
        align-items: center;
        margin:0 20%;
        padding-left:20%;
        border: 1px solid black;
		padding: 10px;
		background-color: #f5f5f5;
		box-shadow: 2px 2px 5px rgba(0,0,0,0.3);
        text-align: center;
        margin-top: -2%;
        padding-top: -4%;
        padding-bottom: 30px;
        background-color: red;
        
    }
    .card-header .box{
        margin:0 5%;
        padding-left:30%;
        border: 1px solid black;
		padding: 13px;
		background-color: white;
        padding-bottom;: 30px
     
         
    }
    .card-header h4{
      font-size: 1.5rem;
      text-align: center;
      font-style: normal;
      color: goldenrod;
      font-family: sans-serif;
      text-transform: uppercase;  
    }
  .form-group  label{
        font-size: 1.4rem;
    }
  .btn{
    
    border-radius: .5rem;
    border-color: black;
    font-size: 2rem;
    cursor: pointer;
    font-family: revert-layer;
    text-transform: uppercase;
    text-decoration: none;
}
  .btn :hover{
    color: blue;

  }
  .box .btn{
    background-color: grey;
    cursor: pointer;
    border-radius: .4rem;
    margin-right:29%;
    margin-left:29%;
    border-color: white;
    
  }

  
</style>




        

