<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, intial-scale=1.0">
    
    
 <div class="logo">
    <img src="logo.jpg" alt="">
    
</head>
<body>
<header class="header">
<h2>Istanbul Medipol University</h2>
        <nav class="navbar">
        <a href="http://localhost/May Myat Noe Naing/phpecom/admin/index.php">dashboad</a>
         <a href="https://www.medipol.edu.tr/">about</a>
         <a href="http://localhost/May Myat Noe Naing/phpecom/signin/login.php">sign-in</a>
        
</nav>
</header>




<style>
.header{
    background: darkblue;
    display: flex;
    justify-content: space-between;
    padding: .7rem 7%;
    border-bottom: black;
    top:0; left: 0; right: 0;
    z-index:1000; 
 
}
.logo img{
    height:6.5rem;
    border-radius: 5%;
    justify-content: flex-start;
    width: 6.5rem;
}    
.header .navbar a{
    margin: 0 1rem;
    font-size: 1rem;
    color: #fff;
    text-transform: uppercase;
    text-decoration-color: burlywood;
    text-decoration-line: none;
    justify-content: flex-end;
    padding-bottom: 2%;
   
}    
    
.header .navbar a:hover{
  
    border-bottom: .1.6rem solid ;
    padding-bottom: .5rem;
    color: darkred;
}  
.header h2{
    font-size: 1.3rem;
    color: #fff;
    justify-content: flex-start;
    margin-left:-7% ;
    font-size: 1.6rem;
    padding-top:-3rem;
      
       
}

</style>
</body>
    </html>